window.MUNDO_FLIX_CONFIG={supabaseUrl:"https://ukarfzjlchkgbatwdmua.supabase.co",supabaseKey:"sb_publishable_881DgYKJPpkQgNP_hy9ZwA_HMqnwlFt"};
