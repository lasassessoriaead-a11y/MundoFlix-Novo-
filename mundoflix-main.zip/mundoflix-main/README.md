# Mundo Flix — PWA conectado ao Supabase

Esta versão usa o projeto Supabase real do Mundo Flix para:
- autenticação;
- títulos;
- clientes;
- vendas;
- status de canais e acessos.

## Abrir localmente
Por usar módulos JavaScript e service worker, sirva a pasta em um servidor web; não abra apenas via file://.

## Hospedagem
Pode ser hospedado em qualquer hospedagem estática HTTPS.

## Telegram
A criação real de canais usando a conta pessoal do Telegram exige um serviço separado MTProto/Telethon.
O banco Supabase já está preparado para receber IDs/status dos canais e links de acesso.
